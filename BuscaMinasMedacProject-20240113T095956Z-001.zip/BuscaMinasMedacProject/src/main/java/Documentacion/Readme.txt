3 Intentos
Array bidimensional para tablero
Metodo borrar resultados
Lista de personas
Objeto persona (Nombre,puntuacion,fecha)

Boton ver instrucciones 
BBDD--> Nombre,puntuacion,fecha
Venta juegos --> volver a jugar , seleccionar 

En la ventana de TableroGUI hay que editar la parte de partida perdida y empatada de piedra papel o tijera por un JOptionPane personalizado (Me da pereza)
Añadidas las distintas formas de perder la partida
Solucionado el bucle infinito al equivocarte en el piedra papel o tijera